import React, {Component} from 'react';
import PropTypes from 'prop-types';
import List from './List';

class Welcome extends Component {

    static propTypes = {
        username: PropTypes.string.isRequired,
        handleLogout: PropTypes.func.isRequired,
        handleListDir: PropTypes.func.isRequired
    };

    state = {
        username : '',
        dirList:[]
    };

    componentWillMount(){
        this.setState({
            username : this.props.username
        });
        //document.title = `Welcome, ${this.state.username} !!`;
    }

    componentDidMount(){
        document.title = `Welcome, ${this.state.username} !!`;
    }

    render(){
        var list =[];
        return(
            <div className="row justify-content-md-center">
                <div className="col-md-3">
                    <div className="alert alert-warning" role="alert">
                        {this.state.username}, welcome to my App..!!
                    </div>
                    <button
                        className="btn btn-danger"
                        type="button"
                        onClick={() => {this.props.handleLogout(this.state)}}>
                        Logout
                    </button>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <button
                        className="btn btn-success"
                        type="button"
                        onClick={() => this.props.handleListDir()}>
                        List Dir
                    </button>

                    <div>


                        {this.props.dirList.map((item) => {return <List value={item}></List>})}
                    </div>
                </div>
            </div>
        )
    }
}

export default Welcome;