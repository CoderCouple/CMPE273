import React, {Component} from 'react';

class List extends React.Component {
    render() {
        return <li>{this.props.value}</li>;
    }
}

export default List;
