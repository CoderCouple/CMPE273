var kafka = require('kafka-node');

function ConnectionProvider() {
    this.getConsumer = function() {
        console.log("In Consumer");
        if (!this.kafkaConsumerConnection) {

            console.log("In Consumer connecvtion");

            this.client = new kafka.Client("localhost:2181");
            this.kafkaConsumerConnection = new kafka.Consumer(this.client,[ { topic: "login_topic", partition: 0 },{ topic: "list_dir_topic", partition: 0 }]);
            this.client.on('ready', function () { console.log('client ready!') })
        }
        console.log("out Consumer connecvtion");
        return this.kafkaConsumerConnection;
    };

    //Code will be executed when we start Producer
    this.getProducer = function() {
        console.log("In side Producer");
        if (!this.kafkaProducerConnection) {
            console.log("In Producer Connection");
            this.client = new kafka.Client("localhost:2181");
            var HighLevelProducer = kafka.HighLevelProducer;
            this.kafkaProducerConnection = new HighLevelProducer(this.client);
            //this.kafkaConnection = new kafka.Producer(this.client);
            console.log('producer ready');
        }
        console.log("out side Producer Connection");
        return this.kafkaProducerConnection;
    };
}
exports = module.exports = new ConnectionProvider;