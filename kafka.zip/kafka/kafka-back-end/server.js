var connection =  new require('./kafka/Connection');
var login = require('./services/login');
var list_dir = require('./services/list_dir');

//var topic_name = 'login_topic';
var consumer = connection.getConsumer();
var producer = connection.getProducer();


//var topic_name1 = 'list_dir_topic';
//var consumer1 = connection.getConsumer(topic_name1);
//var producer1 = connection.getProducer();


console.log('server is running');
consumer.on('message', function (message) {
    console.log('message received');
    console.log(JSON.stringify(message.value));
    var data = JSON.parse(message.value);
    console.log("message Data",data);
    console.log("message Data topic",data.data.topic);
    if(message.topic=="login_topic")
    {
    login.handle_request(data.data, function(err,res){
        console.log('after handle',res);
        var payloads = [
            { topic: data.replyTo,
                messages:JSON.stringify({
                    correlationId:data.correlationId,
                    data : res
                }),
                partition : 0
            }
        ];
        producer.send(payloads, function(err, data){
            console.log(data);
        });
        return;
    });
}else if(message.topic=="list_dir_topic"){

    list_dir.handle_request(data.data, function(err,res){
        console.log('after handle',res);
        var payloads = [
            { topic: data.replyTo,
                messages:JSON.stringify({
                    correlationId:data.correlationId,
                    data : res
                }),
                partition : 0
            }
        ];
        producer.send(payloads, function(err, data){
            console.log('producer data',data);
        });
        return;
    });
}


});

/*consumer1.on('message', function (message) {
    console.log('message received');
    console.log(JSON.stringify(message.value));
    var data = JSON.parse(message.value);
    list_dir.handle_request(data.data, function(err,res){
        console.log('after handle'+res);
        var payloads = [
            { topic: data.replyTo,
                messages:JSON.stringify({
                    correlationId:data.correlationId,
                    data : res
                }),
                partition : 0
            }
        ];
        producer1.send(payloads, function(err, data){
            console.log(data);
        });
        return;
    });
});
*/