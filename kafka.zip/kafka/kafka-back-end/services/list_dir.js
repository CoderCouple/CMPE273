const fs = require('fs')
const path = require('path')
const testFolder = './';

function handle_request(msg, callback){

    var res = {};
    console.log("In handle request:"+ JSON.stringify(msg));



//var dirs = fs.readdirSync(testFolder);
var dirs = [];
var i=1;
fs.readdirSync(testFolder).forEach((file) => {
  console.log(file);
  //var newFile = "File" + i;
  //dirs[newFile]=file;
  //i++;
  dirs.push(file);
})

console.log(dirs);
//console.log("dirs",JSON.stringify(dirs));
//console.log("dirs",dirs.toString());



    res.code = "200";
    res.value = dirs;
    console.log('My response',res);
    callback(null, res);
}

exports.handle_request = handle_request;